#include <stdio.h>
#include <conio.h>
int main()
{
	int *ptr=5;
	printf("%x",ptr);
getch();
return 1
}