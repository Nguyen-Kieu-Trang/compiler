#include<stdio.h>
#include<string.h>
int main()
{
    structure hotel
    {
        int items;
        char name[10];
    }a;
    strcpy(a.name, "TAJ");
    a.items=10;
    printf("%s", a.name);
    return 0;
}
