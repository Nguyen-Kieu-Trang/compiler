#include<stdio.h>
main()
{
    int a=0;
    a = printf("4");
    printf("%d",a);
}
