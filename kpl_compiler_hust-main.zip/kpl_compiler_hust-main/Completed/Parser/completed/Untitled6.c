#include <stdio.h> 
int main()
{
    while(true)    
    {
        printf("RABBIT");
        break;
    }
    
    return 0;
}
