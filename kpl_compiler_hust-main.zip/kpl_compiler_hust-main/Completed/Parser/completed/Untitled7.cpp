#include <stdio.h> 
int main()
{
    int a=25;
    
    while(a <= 27)
    {
        printf("%d ", a);
        a++;
    }

    return 0;
}
