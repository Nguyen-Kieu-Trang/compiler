#include<stdio.h>
main()
{
    int a=0;
    a = 5<2 ? 4 : 3;
    printf("%d",a);
}
