#include<stdio.h>
main()
{
    int a=0, b;
    a = (5>2) ? b=6: b=8;
    printf("%d %d",a, b);
}
