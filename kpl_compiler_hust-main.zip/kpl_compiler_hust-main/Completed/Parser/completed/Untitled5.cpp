#include <stdio.h> 
main() 
{ 
    int i = 0; 
    switch (i) 
    { 
        case '0': printf("Hello"); 
                break; 
        case '1': printf("World"); 
                break; 
        default: printf("HelloWord"); 
    } 
}  
