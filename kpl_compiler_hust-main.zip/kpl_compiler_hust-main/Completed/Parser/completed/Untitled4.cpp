#include<stdio.h>
main()
{
    if( 4 > 5 )
    {
        printf("Hurray");
    }
     printf("Yes");
}
